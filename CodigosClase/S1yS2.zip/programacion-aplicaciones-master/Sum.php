<?php


    class Sum{

        public $val01;
        public $val02;
        public $total;

        public function calculateSum($val01,$val02){

            $total = $val01 + $val02;
            return $total;
        }

        /*public function calculateSum($x,$y){
            $this->val01 = $x;
            $this->val02 = $y;
            $this->total = $this->val01 + $this->val02;
            return $this->total;
        }

        public function calculate02(){
            $this->total = $this->val01 + $this->val02;
        }*/


    }


?>






