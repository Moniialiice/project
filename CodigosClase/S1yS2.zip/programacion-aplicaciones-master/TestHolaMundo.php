<?php

	include ('HolaMundo.php');
	
	$objeto = new HolaMundo();

	$objeto->saludar();

?>