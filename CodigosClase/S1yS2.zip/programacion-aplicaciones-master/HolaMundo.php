<?php

	class HolaMundo{
		
		public $saludo = "Hola Mundo";
		
		public function saludar(){
			
			echo "<h1>".$this->saludo."</h1>";
			
		}
		
	}

?>