<?php

	include ('Product.php');
	
	$auto = new Product();
	
	$auto->getProduct();
	$auto->showProduct();


?>

