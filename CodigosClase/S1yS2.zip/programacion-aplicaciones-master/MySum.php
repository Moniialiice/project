<?php

    require ('Sum.php');

    $object = new Sum();
    $result = $object->calculateSum(5,9);
    echo "<br> total: ".$result;

   /* echo "<br>Valor 01:".$object->val01;
    echo "<br>Valor 02:".$object->val02;
    echo "<br>Resultado = ".$object->total;
    echo "<br>Resultado = ".$result;

    $object->val01 = 15;
    $object->val02 = 5;
    $object->calculate02();
    echo "<br><br>".$object->total;*/

?>













